// Initialize sample data if localStorage is empty
const defaultTasks = [
  { id: 1, title: "Complete Week 1 Architecture", desc: "Prepare system diagrams and database schema", priority: "High", status: "Completed", date: "2026-11-13" },
  { id: 2, title: "Build Front-End Application", desc: "Develop responsive HTML, CSS, and JS views", priority: "High", status: "Pending", date: "2026-11-14" },
  { id: 3, title: "Setup REST API Endpoints", desc: "Create Express server routes for CRUD operations", priority: "Medium", status: "Pending", date: "2026-11-16" }
];

function getTasks() {
  const stored = localStorage.getItem("taskflow_tasks");
  if (!stored) {
    localStorage.setItem("taskflow_tasks", JSON.stringify(defaultTasks));
    return defaultTasks;
  }
  return JSON.parse(stored);
}

function saveTasks(tasks) {
  localStorage.setItem("taskflow_tasks", JSON.stringify(tasks));
}

// Dashboard Page Logic
const taskListEl = document.getElementById("task-list");
if (taskListEl) {
  const filterEl = document.getElementById("filter-status");
  const formEl = document.getElementById("task-form");

  function renderDashboard() {
    const tasks = getTasks();
    const filter = filterEl.value;

    document.getElementById("total-count").textContent = tasks.length;
    document.getElementById("pending-count").textContent = tasks.filter(t => t.status === "Pending").length;
    document.getElementById("completed-count").textContent = tasks.filter(t => t.status === "Completed").length;

    const filtered = filter === "All" ? tasks : tasks.filter(t => t.status === filter);
    taskListEl.innerHTML = filtered.map(task => `
      <div class="task-item">
        <div>
          <h4>${task.title}</h4>
          <small>Due: ${task.date} | Status: <strong>${task.status}</strong></small>
        </div>
        <div>
          <span class="badge ${task.priority}">${task.priority}</span>
          <a href="detail.html?id=${task.id}" class="btn-primary">View / Edit</a>
        </div>
      </div>
    `).join("");
  }

  formEl.addEventListener("submit", (e) => {
    e.preventDefault();
    const tasks = getTasks();
    const newTask = {
      id: Date.now(),
      title: document.getElementById("task-title").value,
      desc: document.getElementById("task-desc").value,
      priority: document.getElementById("task-priority").value,
      status: "Pending",
      date: document.getElementById("task-date").value
    };
    tasks.push(newTask);
    saveTasks(tasks);
    formEl.reset();
    renderDashboard();
  });

  filterEl.addEventListener("change", renderDashboard);
  renderDashboard();
}

// Detail Page Logic
const editFormEl = document.getElementById("edit-form");
if (editFormEl) {
  const params = new URLSearchParams(window.location.search);
  const taskId = Number(params.get("id"));
  const tasks = getTasks();
  const taskIndex = tasks.findIndex(t => t.id === taskId);

  if (taskIndex !== -1) {
    const task = tasks[taskIndex];
    document.getElementById("edit-title").value = task.title;
    document.getElementById("edit-desc").value = task.desc;
    document.getElementById("edit-priority").value = task.priority;
    document.getElementById("edit-status").value = task.status;
    document.getElementById("edit-date").value = task.date;

    editFormEl.addEventListener("submit", (e) => {
      e.preventDefault();
      tasks[taskIndex] = {
        ...task,
        title: document.getElementById("edit-title").value,
        desc: document.getElementById("edit-desc").value,
        priority: document.getElementById("edit-priority").value,
        status: document.getElementById("edit-status").value,
        date: document.getElementById("edit-date").value
      };
      saveTasks(tasks);
      window.location.href = "dashboard.html";
    });

    document.getElementById("delete-btn").addEventListener("click", () => {
      tasks.splice(taskIndex, 1);
      saveTasks(tasks);
      window.location.href = "dashboard.html";
    });
  }
}
