const API_BASE_URL = "http://localhost:5000/api/tasks";

async function fetchTasks(status = "All") {
  try {
    const url = status === "All" ? API_BASE_URL : `${API_BASE_URL}?status=${status}`;
    const response = await fetch(url);
    if (!response.ok) throw new Error("Failed to fetch tasks");
    const result = await response.json();
    return result.data;
  } catch (error) {
    console.warn("Backend offline, using local cache:", error.message);
    return JSON.parse(localStorage.getItem("taskflow_tasks") || "[]");
  }
}

// Dashboard Logic
const taskListEl = document.getElementById("task-list");
if (taskListEl) {
  const filterEl = document.getElementById("filter-status");
  const formEl = document.getElementById("task-form");

  async function renderDashboard() {
    const allTasks = await fetchTasks("All");
    const filter = filterEl.value;
    const displayed = filter === "All" ? allTasks : allTasks.filter(t => t.status === filter);

    document.getElementById("total-count").textContent = allTasks.length;
    document.getElementById("pending-count").textContent = allTasks.filter(t => t.status === "Pending").length;
    document.getElementById("completed-count").textContent = allTasks.filter(t => t.status === "Completed").length;

    taskListEl.innerHTML = displayed.map(task => `
      <div class="task-item">
        <div>
          <h4>${task.title}</h4>
          <small>Due: ${task.date} | Status: <strong>${task.status}</strong></small>
        </div>
        <div>
          <span class="badge ${task.priority}">${task.priority}</span>
          <a href="detail.html?id=${task.id}" class="btn-primary">View / Edit</a>
        </div>
      </div>
    `).join("");
  }

  formEl.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = {
      title: document.getElementById("task-title").value,
      desc: document.getElementById("task-desc").value,
      priority: document.getElementById("task-priority").value,
      status: "Pending",
      date: document.getElementById("task-date").value
    };

    try {
      const response = await fetch(API_BASE_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!response.ok) throw new Error("Failed to create task");
      formEl.reset();
      await renderDashboard();
    } catch (error) {
      alert("Error: " + error.message);
    }
  });

  filterEl.addEventListener("change", renderDashboard);
  renderDashboard();
}

// Detail & Edit Page Logic
const editFormEl = document.getElementById("edit-form");
if (editFormEl) {
  const params = new URLSearchParams(window.location.search);
  const taskId = params.get("id");

  async function loadTaskDetails() {
    try {
      const response = await fetch(`${API_BASE_URL}/${taskId}`);
      if (!response.ok) throw new Error("Task not found");
      const { data: task } = await response.json();

      document.getElementById("edit-title").value = task.title;
      document.getElementById("edit-desc").value = task.desc;
      document.getElementById("edit-priority").value = task.priority;
      document.getElementById("edit-status").value = task.status;
      document.getElementById("edit-date").value = task.date;
    } catch (error) {
      alert("Unable to load task: " + error.message);
    }
  }

  editFormEl.addEventListener("submit", async (e) => {
    e.preventDefault();
    const updatedTask = {
      title: document.getElementById("edit-title").value,
      desc: document.getElementById("edit-desc").value,
      priority: document.getElementById("edit-priority").value,
      status: document.getElementById("edit-status").value,
      date: document.getElementById("edit-date").value
    };

    try {
      const response = await fetch(`${API_BASE_URL}/${taskId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedTask)
      });
      if (!response.ok) throw new Error("Failed to update task");
      window.location.href = "dashboard.html";
    } catch (error) {
      alert("Update error: " + error.message);
    }
  });

  document.getElementById("delete-btn").addEventListener("click", async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/${taskId}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Failed to delete task");
      window.location.href = "dashboard.html";
    } catch (error) {
      alert("Delete error: " + error.message);
    }
  });

  loadTaskDetails();
}
